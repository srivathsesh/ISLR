library(testthat)
library(yardstick)

test_check("yardstick")

Contributors to `recipes` package (sorted alphabetically)
-------
* **[Lionel Henry](https://github.com/lionel-)**

 * [PR](https://github.com/topepo/recipes/pull/66) that greatly simplified the selection code. 
 
* **Kirk Mettler**

 * Contributed to the imported `caret` code for linear combination identification. 

* **Jed Wing**

 * Contributed to the imported `caret` code for linear combination identification.
 
* **[Alex Hayes](https://github.com/alexpghayes)**

 * Contributed initial implementations of `step_intercept` and `step_relu`.
